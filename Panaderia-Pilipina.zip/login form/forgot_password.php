<?php
session_start();
require_once __DIR__ . '/../account_store.php';
require_once __DIR__ . '/../login_guard.php';

header('Cache-Control: no-store, private');
header('Referrer-Policy: no-referrer');

$message = '';
$messageIsError = true;
$csrfToken = $_SESSION['password_change_csrf'] ??= bin2hex(random_bytes(32));
$verifiedRole = (string)($_SESSION['password_reset_demo_role'] ?? '');
$verifiedEmail = (string)($_SESSION['password_reset_demo_email'] ?? '');
$verifiedUntil = (int)($_SESSION['password_reset_demo_expires'] ?? 0);

if ($verifiedRole !== '' && $verifiedUntil < time()) {
    unset(
        $_SESSION['password_reset_demo_role'],
        $_SESSION['password_reset_demo_email'],
        $_SESSION['password_reset_demo_expires']
    );
    $verifiedRole = '';
    $verifiedEmail = '';
    $message = 'This demo reset expired. Please enter your email again.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submittedToken = $_POST['csrf_token'] ?? null;
    if (!is_string($submittedToken) || !hash_equals($csrfToken, $submittedToken)) {
        $message = 'Your request could not be verified. Refresh the page and try again.';
    } elseif (($_POST['action'] ?? '') === 'verify_email') {
        if (!loginGuardAllowsAttempt('password_reset_demo')) {
            $message = 'Too many attempts. Please try again in a few minutes.';
        } else {
            $emailValue = $_POST['email'] ?? '';
            $email = is_string($emailValue) ? strtolower(trim($emailValue)) : '';
            $emailExists = false;

            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                foreach (loadCustomerAccounts() as $account) {
                    if (strtolower((string)($account['email'] ?? '')) === $email) {
                        $emailExists = true;
                        $role = 'customer';
                        break;
                    }
                }
                if (!$emailExists && appAdminCredentialsReady() && hash_equals(appAdminEmail(), $email)) {
                    $emailExists = true;
                    $role = 'admin';
                }
            }

            if (!$emailExists) {
                loginGuardRecordFailure('password_reset_demo');
                $message = 'Wrong email. Please check the email address and try again.';
            } else {
                loginGuardReset('password_reset_demo');
                session_regenerate_id(true);
                $_SESSION['password_reset_demo_role'] = $role;
                $_SESSION['password_reset_demo_email'] = $email;
                $_SESSION['password_reset_demo_expires'] = time() + 600;
                $_SESSION['password_change_csrf'] = bin2hex(random_bytes(32));
                header('Location: forgot_password.php?stage=new-password');
                exit();
            }
        }
    } elseif (($_POST['action'] ?? '') === 'demo_reset') {
        $verifiedRole = (string)($_SESSION['password_reset_demo_role'] ?? '');
        $verifiedEmail = strtolower((string)($_SESSION['password_reset_demo_email'] ?? ''));
        $verifiedUntil = (int)($_SESSION['password_reset_demo_expires'] ?? 0);
        $newPasswordValue = $_POST['new_password'] ?? '';
        $confirmPasswordValue = $_POST['confirm_password'] ?? '';
        $newPassword = is_string($newPasswordValue) ? $newPasswordValue : '';
        $confirmPassword = is_string($confirmPasswordValue) ? $confirmPasswordValue : '';

        if (!in_array($verifiedRole, ['admin', 'customer'], true) || $verifiedEmail === '' || $verifiedUntil < time()) {
            $message = 'This demo reset expired. Please enter your email again.';
            unset(
                $_SESSION['password_reset_demo_role'],
                $_SESSION['password_reset_demo_email'],
                $_SESSION['password_reset_demo_expires']
            );
        } elseif (!customerPasswordIsStrong($newPassword)) {
            $message = 'Use at least 8 characters with uppercase and lowercase letters, a number, and a symbol.';
        } elseif ($newPassword !== $confirmPassword) {
            $message = 'Passwords do not match.';
        } else {
            $message = 'Demo complete. The password was not saved or changed.';
            $messageIsError = false;
        }
    } else {
        $message = 'Invalid request. Please try again.';
    }

    $csrfToken = (string)($_SESSION['password_change_csrf'] ??= bin2hex(random_bytes(32)));
    $verifiedRole = (string)($_SESSION['password_reset_demo_role'] ?? '');
    $verifiedEmail = (string)($_SESSION['password_reset_demo_email'] ?? '');
}

$showNewPasswordForm = $verifiedRole !== ''
    && $verifiedEmail !== ''
    && (int)($_SESSION['password_reset_demo_expires'] ?? 0) >= time()
    && ($_GET['stage'] ?? '') === 'new-password';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panaderia Pilipina | Password Reset</title>
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; padding: 20px; display: grid; place-items: center; font-family: Arial, sans-serif; background: linear-gradient(135deg, #fff7ed, #fed7aa, #f59e0b); }
        .recovery-box { width: min(430px, 100%); padding: 30px 25px; border: 2px solid #f59e0b; border-radius: 18px; background: #fffdf9; box-shadow: 0 14px 30px rgba(146, 64, 14, .2); }
        h1 { margin: 0 0 8px; text-align: center; color: #7c2d12; font-size: 1.7rem; }
        .subtitle { margin: 0 0 20px; text-align: center; color: #78716c; line-height: 1.5; font-size: .9rem; }
        .field { margin-bottom: 15px; }
        label { display: block; margin-bottom: 6px; color: #7c2d12; font-weight: 700; }
        input, select { width: 100%; padding: 11px 12px; border: 1px solid #fbbf24; border-radius: 8px; background: #fffdf7; font-size: 14px; }
        button, .link { display: block; width: 100%; padding: 12px; border: 0; border-radius: 10px; background: linear-gradient(135deg, #d97706, #b45309); color: #fff; text-align: center; text-decoration: none; font-size: 16px; font-weight: 700; cursor: pointer; }
        .message { margin-bottom: 15px; padding: 10px; border-radius: 8px; font-size: 14px; }
        .message.error { background: #fef2f2; color: #b91c1c; border: 1px solid #fecaca; }
        .message.success { background: #ecfdf5; color: #166534; border: 1px solid #bbf7d0; }
        .link { margin-top: 14px; background: transparent; color: #a16207; font-size: 14px; }
    </style>
</head>
<body>
    <main class="recovery-box">
        <h1><?php echo $showNewPasswordForm ? 'Set New Password' : 'Forgot Password?'; ?></h1>
        <p class="subtitle"><?php echo $showNewPasswordForm
            ? 'Demo reset for ' . htmlspecialchars($verifiedEmail, ENT_QUOTES, 'UTF-8') . '. Choose a new password to preview the next step.'
            : 'Demo only: enter the registered email to preview the password reset form.'; ?></p>
        <?php if ($message !== ''): ?>
            <p class="message <?php echo $messageIsError ? 'error' : 'success'; ?>" role="<?php echo $messageIsError ? 'alert' : 'status'; ?>"><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></p>
        <?php endif; ?>

        <?php if ($showNewPasswordForm): ?>
            <form method="post" action="forgot_password.php?stage=new-password">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="action" value="demo_reset">
                <div class="field">
                    <label for="new_password">New password</label>
                    <input id="new_password" name="new_password" type="password" minlength="8" autocomplete="new-password" required>
                </div>
                <div class="field">
                    <label for="confirm_password">Confirm password</label>
                    <input id="confirm_password" name="confirm_password" type="password" minlength="8" autocomplete="new-password" required>
                </div>
                <button type="submit">Update Password</button>
            </form>
        <?php else: ?>
            <form method="post" action="forgot_password.php">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="action" value="verify_email">
                <div class="field">
                    <label for="email">Email address</label>
                    <input id="email" name="email" type="email" autocomplete="username" required>
                </div>
                <button type="submit">Confirm Email</button>
            </form>
        <?php endif; ?>
        <a class="link" href="customer_login.php">Back to Log In</a>
    </main>
</body>
</html>
